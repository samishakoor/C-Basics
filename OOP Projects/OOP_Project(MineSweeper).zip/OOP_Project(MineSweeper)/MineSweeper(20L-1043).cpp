#include<iostream>
#include<iomanip>
#include<stdlib.h>
using namespace std;


class Game
{

protected:

int rows=5;
int cols=5;

char **MainTable;
char **ShowTable;

public:

Game(int rows , int cols);
void MakeMainTable ();
void MakeShowTable ();
virtual void PrintShowTable()=0;
~Game();

};


Game::Game(int rows , int cols)
{

this->rows=rows;
this->cols=cols;

MainTable=new char *[rows];
ShowTable=new char* [rows];

for (int i=0 ; i<rows  ; i++)
    {
       MainTable[i]=new char[cols];
    }

 for (int i=0 ; i<rows  ; i++)
    {
       ShowTable[i]=new char[cols];
    }

}


Game::~Game()
{
 if(    MainTable != NULL && ShowTable != NULL)
 {
   for(int i=0 ;i<rows ; i++)
     {
       delete [] MainTable[i];
       delete [] ShowTable[i];
     }
     delete [] MainTable;
     delete [] ShowTable;
 }
}

void Game::MakeMainTable ()
{


 for (int i=0 ; i<rows ; i++)
    {
    for(int j=0 ; j<cols ; j++)
        {
          MainTable[i][j]='X';
        }
    }
}

void Game::MakeShowTable ()
{
 for (int i=0 ; i<rows ; i++)
    {
    for(int j=0 ; j<cols ; j++)
        {
          ShowTable[i][j]='X';
        }
    }
}




class MineSweeper : public Game
{

public:

MineSweeper(int r ,int c);
void PrintShowTable();
void PlaceMines();
void PlayGame();
~MineSweeper();

};



MineSweeper::MineSweeper(int r, int c) :Game(r, c)
{

}

void MineSweeper::PrintShowTable()
{
cout<<"BOARD : "<<endl;
 for (int i=0 ; i<rows ; i++)
    {
    for(int j=0 ; j<cols ; j++)
        {
         cout<<setw(5)<<ShowTable[i][j];
        }
        cout<<endl;
    }

}

void MineSweeper::PlaceMines()
{

int no_of_mines=5;
srand(time(NULL));
    for (int i=0 ; i<no_of_mines ; i++)
    {
         int a;
         int b;
      while(true)
      {
          a=rand()%(rows-1);
          b=rand()%(cols-1);
          if(a==0 && b==0)
          {
              i--;
              break;
          }
          if(MainTable[a][b]!='M')
            {
               MainTable[a][b]='M';
               break;
            }
      }
}

}

 void MineSweeper::PlayGame()
 {


 int x;
        int y;
        bool isMine = false;

        while (!isMine)
        {
            int count = 0;
            cout << "Enter Coordinates (x,y) : ";
            cin >> x >> y;
            cout << endl;
            if (x >= 0 && y >= 0 && x < rows && y < cols)
            {
                if (MainTable[x][y] != 'M')
                {
                    if (x != 0)
                    {
                        if (MainTable[x - 1][y] == 'M')
                        {
                            count++;
                        }
                    }
                    if (x < 4)
                    {
                        if (MainTable[x + 1][y] == 'M')
                        {
                            count++;
                        }
                    }
                    if (y < 4)
                    {
                        if (MainTable[x][y + 1] == 'M')
                        {
                            count++;
                        }

                    }
                    if (y != 0)
                    {
                        if (MainTable[x][y - 1] == 'M')
                        {
                            count++;
                        }
                    }
                    if (x != 0 && y < 4)
                    {
                        if (MainTable[x - 1][y + 1] == 'M')
                        {
                            count++;
                        }
                    }
                    if (x != 0 && y != 0)
                    {
                        if (MainTable[x - 1][y - 1] == 'M')
                        {
                            count++;
                        }
                    }
                    if (x < 4 && y < 4)
                    {
                        if (MainTable[x + 1][y + 1] == 'M')
                        {
                            count++;
                        }
                    }
                    if (x < 4 && y != 0)
                    {
                        if (MainTable[x + 1][y - 1] == 'M')
                        {
                            count++;
                        }
                    }
                    if (x == 0 && y == 0)
                    {

                        for (int i = 0; i < 2; i++)
                            for (int j = 0; j < cols; j++)
                            {
                                int count = 0;
                                if (i != 0)
                                {
                                    if (MainTable[i - 1][j] == 'M')
                                    {
                                        count++;
                                    }
                                }
                                if (i < 2)
                                {
                                    if (MainTable[i + 1][j] == 'M')
                                    {
                                        count++;
                                    }
                                }
                                if (j < 4)
                                {
                                    if (MainTable[i][j + 1] == 'M')
                                    {
                                        count++;
                                    }

                                }
                                if (j != 0)
                                {
                                    if (MainTable[i][j - 1] == 'M')
                                    {
                                        count++;
                                    }
                                }
                                if (i != 0 && j < 4)
                                {
                                    if (MainTable[i - 1][j + 1] == 'M')
                                    {
                                        count++;
                                    }
                                }
                                if (i != 0 && j != 0)
                                {
                                    if (MainTable[i - 1][j - 1] == 'M')
                                    {
                                        count++;
                                    }
                                }
                                if (i < 4 && j < 4)
                                {
                                    if (MainTable[i + 1][j + 1] == 'M')
                                    {
                                        count++;
                                    }
                                }
                                if (i < 4 && j != 0)
                                {
                                    if (MainTable[i + 1][j - 1] == 'M')
                                    {
                                        count++;
                                    }
                                }
                                if (MainTable[i][j] == 'M')
                                    ShowTable[i][j] = 'X';
                                else
                                    ShowTable[i][j] = count + '0';
                            }
                        for(int i=2;i<5;i++)
                            for (int j = 0; j < 5; j++)
                            {
                                ShowTable[i][j] = 'X';
                            }

                        PrintShowTable();
                    }

                    else
                    {
                        ShowTable[x][y] = count + '0';
                        PrintShowTable();
                    }

                }

                if (MainTable[x][y] == 'M')
                {
                    ShowTable[x][y] = 'M';
                    PrintShowTable();
                    cout << "Sorry ! You Lost The Game , A mine has exploded at location (" << x << "," << y << ")" << endl;
                    isMine = true;
                }
            }

            else
            {
                cout << "Please Enter Appropriate Coordinates ! " << endl << endl;
            }
        }
 }
MineSweeper::~MineSweeper()
{

}

int main()
{

int rows=5;
int cols=5;

MineSweeper m(rows,cols);
m.MakeMainTable();
m.MakeShowTable();

Game * g = & m;
g->PrintShowTable();

MineSweeper *M =dynamic_cast<MineSweeper*>(g);

if(M!=NULL)
{
M->PlaceMines();
M->PlayGame();
}

return 0;
}

